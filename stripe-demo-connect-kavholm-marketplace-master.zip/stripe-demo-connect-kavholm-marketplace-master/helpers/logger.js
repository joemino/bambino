let logger = {
  log: (arg, arg2) => {
    // console.log(arg, arg2);
  },
};

module.exports = logger;
