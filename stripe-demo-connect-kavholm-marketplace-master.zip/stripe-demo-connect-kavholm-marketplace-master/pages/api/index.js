export default (req, res) => {
  res.send('Hello from API');
};
